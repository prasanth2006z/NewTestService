package com.goodies.authn.repository;

import com.goodies.authn.entity.Account;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;
/**
 * @Author: pxp167
 * @Date: 11/5/2018
 *
 */
public interface AccountRepository  extends JpaRepository<Account, Long> {

  Optional<Account> findByUsername(String username);
}
