package com.goodies.authn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableResourceServer;

@SpringBootApplication
public class AuthnServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(AuthnServiceApplication.class, args);
	}
}
