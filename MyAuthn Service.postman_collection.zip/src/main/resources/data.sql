--Oauth - populate the oauth_client_details table
INSERT INTO `oauth_client_details` (`client_id`, `client_secret`, `scope`, `authorized_grant_types`, `access_token_validity`, `additional_information`)
VALUES
('webtest', '$2a$04$xEdeBcWAJLLqILISmlJQWO8XGt4nXSxgGX1JpI19.MYdwqC59ycOe', 'read', 'client_credentials,password,authorization_code,refresh_token', '900', '{}')
ON DUPLICATE key UPDATE
client_secret = VALUES(`client_secret`),
scope = VALUES(`scope`),
authorized_grant_types = VALUES(`authorized_grant_types`),
access_token_validity = VALUES(`access_token_validity`),
additional_information = VALUES(`additional_information`);

INSERT INTO `oauth`.`account` (`id`, `password`, `username`) VALUES ('	1	', '$2a$04$mU2jJN3TcKItjCTMsjn02OXlbGemPBWNuQna4EDjOlYZHDlSAARXe', 'test')
ON DUPLICATE key UPDATE
password = VALUES(`password`),
username = VALUES(`username`);

INSERT INTO `oauth`.`account` (`id`, `password`, `username`) VALUES ('	2	', '$2a$04$mU2jJN3TcKItjCTMsjn02OXlbGemPBWNuQna4EDjOlYZHDlSAARXe', 'test1')
ON DUPLICATE key UPDATE
password = VALUES(`password`),
username = VALUES(`username`);
