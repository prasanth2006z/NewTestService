package com.goodies.authn.AuthnService;


import com.goodies.authn.config.OauthJDBCConfig;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.junit4.SpringRunner;

/*@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
@ActiveProfiles(profiles = "dev")
@ContextConfiguration(classes = {OauthJDBCConfig.class,AuthServerOAuth2Config.class})
@EnableAutoConfiguration*/
public class AuthnServiceApplicationTests {

/*	@Test
	public void contextLoads() {
		System.out.println("test");

	}*/

}
