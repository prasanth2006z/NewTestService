package com.nivi.payment;

import com.nivi.payment.service.PaymentGatewayService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

/**
 * @Author: pxp167
 * @Date: 10/9/2018
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
@ActiveProfiles(profiles = "dev")
@ContextConfiguration(classes = {Config.class})
@EnableAutoConfiguration
public class PaymentGatewayTest {

  @Autowired
  PaymentGatewayService paymentGatewayService;

  @Test
  public void getPaymentByIdTest() {
    try {
      paymentGatewayService.getPaymentById("pay_B74nJCqLLArGa5");
    } catch (Exception e) {
      System.out.println(e.getMessage());
    }
  }

  @Test
  public void searchRefundTest() {
    try {
      paymentGatewayService.fetchRefunds(10);
    } catch (Exception e) {
      System.out.println(e.getMessage());
    }
  }

  @Test
  public void searchByPaymentIdTest() {
    try {
      paymentGatewayService.refundByPaymentId("pay_B74nJCqLLArGa5");
    } catch (Exception e) {
      System.out.println(e.getMessage());
    }
  }

  @Test
  public void searchByRefundIdTest() {
    try {
      paymentGatewayService.searchByRefundId("");
    } catch (Exception e) {
      System.out.println(e.getMessage());
    }
  }

  @Test
  public void fetchRefundsByIdTest() {
    try {
      paymentGatewayService.searchByRefundId("pay_B74nJCqLLArGa5");
    } catch (Exception e) {
      System.out.println(e.getMessage());
    }
  }

  @Test
  public void fetchRefundByPayIdAndRefundIdTest() {
    try {
      paymentGatewayService.fetchRefundByPayIdAndRefundId("pay_B74nJCqLLArGa5", "pay_B74nJCqLLArGa5");
    } catch (Exception e) {
      System.out.println(e.getMessage());
    }
  }

  @Test
  public void confirmTest() {
    try {
      paymentGatewayService.capturePayment("pay_B74nJCqLLArGa5", "2000");
    } catch (Exception e) {
      System.out.println(e.getMessage());
    }
  }

}
