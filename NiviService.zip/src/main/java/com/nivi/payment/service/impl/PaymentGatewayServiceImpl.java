package com.nivi.payment.service.impl;

import com.nivi.payment.service.PaymentGatewayService;
import com.razorpay.Payment;
import com.razorpay.RazorpayClient;
import com.razorpay.RazorpayException;
import com.razorpay.Refund;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

/**
 * @Author: pxp167
 * @Date: 10/9/2018
 *
 */
public class PaymentGatewayServiceImpl implements PaymentGatewayService {

  private static final Logger logger = LogManager.getLogger(PaymentGatewayServiceImpl.class);

  @Autowired
  private RazorpayClient razorpayClient;

  /**
   * GET
   * @param payId
   * @return
   * @throws RazorpayException
   */
  @Override public Payment getPaymentById(String payId) throws RazorpayException {
    logger.debug("dddd");
    return razorpayClient.Payments.fetch(payId);
  }

  /**
   * Capture Payment (POST)
   * @param payId
   * @param amount
   * @throws RazorpayException
   */
  @Override
  public void capturePayment(String payId, String amount) throws RazorpayException {
    JSONObject captureRequest = new JSONObject();
    captureRequest.put("amount", amount);
    Payment payment = razorpayClient.Payments.capture(payId, captureRequest);
  }

  /**
   *
   * @param count
   * @return
   * @throws RazorpayException
   */
  @Override public List<Refund> fetchRefunds(int count) throws RazorpayException {
    JSONObject refundRequest = new JSONObject();
    refundRequest.put("count", count);
    return razorpayClient.Refunds.fetchAll(refundRequest);
  }

  /**
   * GET
   * @param payId
   * @return
   * @throws RazorpayException
   */
  @Override public List<Refund> fetchRefundsByPaymentId(String payId) throws RazorpayException {
    return razorpayClient.Payments.fetchAllRefunds(payId);
  }

  /**
   * POST
   * @param payId
   * @return
   * @throws RazorpayException
   */
  @Override public Refund refundByPaymentId(String payId) throws RazorpayException {
    return razorpayClient.Payments.refund(payId);
  }

  /**
   *
   * @param refundId
   * @return
   * @throws RazorpayException
   */
  @Override public Refund searchByRefundId(String refundId) throws RazorpayException {
    return razorpayClient.Refunds.fetch(refundId);
  }

  /**
   *
   * @param payId
   * @param refundId
   * @return
   * @throws RazorpayException
   */
  @Override public Refund fetchRefundByPayIdAndRefundId(String payId, String refundId) throws RazorpayException {
    return razorpayClient.Payments.fetchRefund(payId, refundId);
  }
}
