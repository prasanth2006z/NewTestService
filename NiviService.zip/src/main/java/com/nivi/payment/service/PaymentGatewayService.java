package com.nivi.payment.service;

import com.razorpay.Payment;
import com.razorpay.RazorpayException;
import com.razorpay.Refund;

import java.util.List;

/**
 * @Author: pxp167
 * @Date: 10/9/2018
 *
 */
public interface PaymentGatewayService {

  Payment getPaymentById(String payId) throws RazorpayException;

  void capturePayment(String payId, String amount) throws RazorpayException;

  List<Refund> fetchRefunds(int count) throws RazorpayException;

  Refund refundByPaymentId(String payId) throws RazorpayException;

  Refund searchByRefundId(String refundId) throws RazorpayException;

  List<Refund> fetchRefundsByPaymentId(String payId) throws RazorpayException;

  Refund fetchRefundByPayIdAndRefundId(String payId, String refundId) throws RazorpayException;

}
