package com.nivi.payment.service;

import java.util.concurrent.Future;

/**
 * @Author: pxp167
 * @Date: 10/9/2018
 *
 */
public interface EmailService {

  Future<Boolean> sedEmail(Object obj);

}
