package com.nivi.payment.service.impl;

import com.nivi.payment.constants.Constants;
import com.nivi.payment.service.EmailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.util.concurrent.Future;

/**
 * @Author: pxp167
 * @Date: 10/9/2018
 *
 */
public class EmailServiceImpl implements EmailService {
  @Autowired
  JavaMailSender emailSender;

  @Async("processExecutor")
  public Future<Boolean> sedEmail(Object obj) {
    if (obj != null) {
      SimpleMailMessage message = new SimpleMailMessage();
      message.setTo(Constants.USER_NAME);
      message.setSubject(Constants.SENT_SUBJECT);
      message.setText(obj.toString());
      emailSender.send(message);
      return new AsyncResult<>(Boolean.TRUE);
    }
    return new AsyncResult<>(Boolean.FALSE);
  }
}
