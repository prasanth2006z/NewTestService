package com.nivi.payment;

import com.nivi.payment.constants.Constants;
import com.nivi.payment.service.EmailService;
import com.nivi.payment.service.PaymentGatewayService;
import com.nivi.payment.service.impl.EmailServiceImpl;
import com.nivi.payment.service.impl.PaymentGatewayServiceImpl;
import com.razorpay.RazorpayClient;
import com.razorpay.RazorpayException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.Properties;
import java.util.concurrent.Executor;

/**
 * @Author: pxp167
 * @Date: 9/26/2018
 *
 */
@ComponentScan(basePackages = "com.nivi")
@Configuration
public class Config {

  @Value("${payment.gateway.key}")
  private String paymentGatewayKey;

  @Value("${payment.gateway.value}")
  private String paymentGatewayValue;

  @Bean
  public RazorpayClient razorpayClient() throws RazorpayException {
    return new RazorpayClient(paymentGatewayKey, paymentGatewayValue);
  }

  @Bean
  public PaymentGatewayService paymentGatewayService() {
    return new PaymentGatewayServiceImpl();
  }

  @Bean
  public EmailService emailService() {
    return new EmailServiceImpl();
  }

  @Bean
  public JavaMailSender emailSender() {
    JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
    mailSender.setHost(Constants.HOST);
    mailSender.setPort(Constants.PORT);
    mailSender.setUsername(Constants.SENT_FROM);
    mailSender.setPassword(Constants.PASSWORD);
    Properties props = mailSender.getJavaMailProperties();
    props.put("mail.transport.protocol", Constants.PROTOCOL);
    props.put("mail.smtp.auth", Constants.AUTH);
    props.put("mail.smtp.starttls.enable", Constants.STARTTLS);
    props.put("mail.debug", Constants.DEBUGG);
    return mailSender;
  }


  @Bean(name = "processExecutor")
  public Executor getAsyncExecutor() {
    ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
    executor.setCorePoolSize(10);
    executor.setMaxPoolSize(10);
    executor.setQueueCapacity(20);
    executor.setThreadNamePrefix("AsyncConfigurerSupportDemo");
    executor.initialize();
    return executor;
  }

}
