package com.nivi.payment.constants;

import java.util.Date;

/**
 * @Author: pxp167
 * @Date: 10/9/2018
 *
 */
public class Constants {

  //mail constants
  public final static String HOST = "smtp.gmail.com";
  public final static int PORT = 587;
  public final static String PROTOCOL = "smtp";
  public final static String AUTH = "true";
  public final static String STARTTLS = "true";
  public final static String DEBUGG = "true";

  public final static String USER_NAME = "MCXAlertSystem@gmail.com";
  public final static String SENT_FROM = "prasanth2006z@gmail.com";
  public final static String PASSWORD = "";
  public final static String SENT_SUBJECT = "NPGS Notification :" + new Date();

  }
