package com.nivi.payment.controller;

import com.nivi.payment.service.PaymentGatewayService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * @Author: pxp167
 * @Date: 10/9/2018
 *
 */
@RestController
public class PaymentGatewayController {

  private static final Logger logger = LogManager.getLogger(PaymentGatewayController.class);

  @Autowired
  private PaymentGatewayService paymentGatewayService;

  /**
   *
   * @param payId
   * @return
   */
  @RequestMapping(value = "/getPaymentById/{payId}", method = RequestMethod.GET)
  @ResponseBody
  public Object getPaymentById(@PathVariable("payId") String payId) {
    try {
      return paymentGatewayService.getPaymentById(payId);
    } catch (Exception e) {
      logger.error(e);
      return e.getMessage();
    }
  }

  /**
   *
   * @param payId
   * @param amount
   */
  @RequestMapping(value = "/capturePayment/{payId}", method = RequestMethod.POST)
  @ResponseBody
  public void capturePayment(@PathVariable("payId") String payId, @RequestBody String amount) {
    try {
      paymentGatewayService.capturePayment(payId, amount);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  /**
   *
   * @param count
   * @return
   */
  @RequestMapping(value = "/fetchRefunds/{count}", method = RequestMethod.GET)
  @ResponseBody
  public Object fetchRefunds(@PathVariable("count") int count) {
    try {
      return paymentGatewayService.fetchRefunds(count);
    } catch (Exception e) {
      return e.getMessage();
    }
  }

  /**
   *
   * @param payId
   * @return
   */
  @RequestMapping(value = "/refund/{payId}", method = RequestMethod.POST)
  @ResponseBody
  public Object refund(@PathVariable("payId") String payId) {
    try {
      return paymentGatewayService.refundByPaymentId(payId);
    } catch (Exception e) {
      return e.getMessage();
    }
  }

  /**
   *
   * @param refundId
   * @return
   */
  @RequestMapping(value = "/searchByRefundId/{refundId}", method = RequestMethod.GET)
  @ResponseBody
  public Object searchByRefundId(@PathVariable("refundId") String refundId) {
    try {
      return paymentGatewayService.searchByRefundId(refundId);
    } catch (Exception e) {
      return e.getMessage();
    }
  }

  /**
   *
   * @param payId
   * @return
   */
  @RequestMapping(value = "/fetchRefundsByPaymentId/{payId}", method = RequestMethod.GET)
  @ResponseBody
  public Object fetchRefundsByPaymentId(@PathVariable("payId") String payId) {
    try {
      return paymentGatewayService.fetchRefundsByPaymentId(payId);
    } catch (Exception e) {
      return e.getMessage();
    }
  }

  /**
   *
   * @param payId
   * @param refundId
   * @return
   */
  @RequestMapping(value = "/fetchRefundByPayIdAndRefundId/{payId}", method = RequestMethod.GET)
  @ResponseBody
  public Object fetchRefundByPayIdAndRefundId(@PathVariable("payId") String payId, @RequestBody String refundId) {
    try {
      return paymentGatewayService.fetchRefundByPayIdAndRefundId(payId, refundId);
    } catch (Exception e) {
      return e.getMessage();
    }
  }

}
