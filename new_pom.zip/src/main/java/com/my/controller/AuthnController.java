package com.my.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 * @Author: pxp167
 * @Date: 11/20/2018
 *
 */
@RestController
public class AuthnController {

  @Autowired
  private UserDetailsService userDetailsService;

  @RequestMapping(method = RequestMethod.GET, value = "/test")
  public void fetchUserByName(){
    userDetailsService.loadUserByUsername("test");
  }
}
