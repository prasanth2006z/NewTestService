package com.my.entity;

import javax.persistence.*;
import java.io.Serializable;

/**
 * @Author: pxp167
 * @Date: 11/16/2018
 *
 */

@Entity
@Table(name = "ROLES")
public class UserRole implements Serializable {
  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  private Long id;

  private String name;

  UserRole() {
  }

  public UserRole(String name) {
    this.name = name;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }
}
