package com.goodies.config;

import com.goodies.entity.User;
import com.goodies.repo.UserRepository;
import com.goodies.security.CrmUserDetails;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
/**
 * @Author: pxp167
 * @Date: 11/16/2018
 *
 */
@Component
@Service("crmUserDetailsService")
@ComponentScan(basePackages = "com.goodies.config")
public class CrmUserDetailsService implements UserDetailsService {

  @Autowired
  private UserRepository userRepository;

  @Override
  public UserDetails loadUserByUsername(String userName) throws UsernameNotFoundException {
    User user = userRepository.findByUsername(userName);
    if(user == null){
      throw new UsernameNotFoundException("UserName "+userName+" not found");
    }
    return new CrmUserDetails(user);
  }

}
