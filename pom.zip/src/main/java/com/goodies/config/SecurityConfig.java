package com.goodies.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.provider.ClientDetailsService;
import org.springframework.security.oauth2.provider.client.JdbcClientDetailsService;
import org.springframework.security.oauth2.provider.token.store.JdbcTokenStore;

import javax.sql.DataSource;
/**
 * @Author: pxp167
 * @Date: 11/16/2018
 *
 */
@Configuration
@EnableWebSecurity
@ComponentScan(basePackages = "com.goodies.config")
public class SecurityConfig extends WebSecurityConfigurerAdapter {

  @Autowired
  private DataSource dataSource;

  private AuthenticationManager authenticationManager;

  @Autowired
  @Qualifier("crmUserDetailsService")
  private UserDetailsService userDetailsService;

  /*@Autowired
  private CrmUserDetailsService CrmUserDetailsService;*/

  public SecurityConfig(@Lazy AuthenticationManager authenticationManager){
    this.authenticationManager=authenticationManager;
  }


  @Override
  protected void configure(AuthenticationManagerBuilder auth) throws Exception {
    //auth.parentAuthenticationManager(authenticationManager);
    auth.userDetailsService(userDetailsService);
      //.passwordEncoder(passwordEncoder());
  }

  @Override
  @Bean
  public AuthenticationManager authenticationManagerBean() throws Exception {
    return super.authenticationManagerBean();
  }

  //-- use the JdbcTokenStore to store tokens








  @Override
  @Order(Ordered.HIGHEST_PRECEDENCE)
  protected void configure(HttpSecurity http) throws Exception {
    http
      .sessionManagement()
      .sessionCreationPolicy(SessionCreationPolicy.STATELESS)
      .and()
      .csrf().disable()
      .authorizeRequests()
      .antMatchers("/about").permitAll()
      .antMatchers("/signup").permitAll()
      .antMatchers("/oauth/token").permitAll()
      //.antMatchers("/api/**").authenticated()
      .anyRequest().authenticated()
      .and()
      .httpBasic()
      .realmName("CRM_REALM");
  }

 /* @Bean
  public ClientDetailsService jdbcClientDetailsService() {
    return new JdbcClientDetailsService(dataSource);
  }*/

}
