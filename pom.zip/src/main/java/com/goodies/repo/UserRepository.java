package com.goodies.repo;

import com.goodies.entity.User;
import org.springframework.data.repository.CrudRepository;

/**
 * @Author: pxp167
 * @Date: 11/16/2018
 *
 */
public interface UserRepository extends CrudRepository<User, Long> {

  User findByUsername(String username);

}
