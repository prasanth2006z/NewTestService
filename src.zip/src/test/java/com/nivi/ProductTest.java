package com.nivi;

import com.nivi.constants.Constant;
import com.nivi.pojo.Product;
import com.nivi.service.ProductService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * @Author: pxp167
 * @Date: 9/28/2018
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
@ActiveProfiles(profiles = "dev")
@ContextConfiguration(classes = {Config.class})
@EnableAutoConfiguration
public class ProductTest {

  @Autowired
  private ProductService productService;

  @Test
  public void testSave(){
    Product product =new Product();
    product.setProductName("Chilli Powder");
    product.setPriceperUnit(20);

    try {
      product.setCreatedDate(new Date());
    } catch (Exception e) {
      e.printStackTrace();
    }
    productService.save(product);
  }

  @Test
  public void testProducts(){
    productService.getProducts();
  }



}
