/*
package com.nivi;

import com.nivi.pojo.Item;
import com.nivi.pojo.Order;
import com.nivi.service.RepoBalanceService;
import org.codehaus.jackson.map.ObjectMapper;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;

*/
/**
 * @Author: pxp167
 * @Date: 9/26/2018
 *
 *//*

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
@ActiveProfiles(profiles = "dev")
@ContextConfiguration(classes = Config.class)
@EnableAutoConfiguration
public class RepoBalanceTest {
  @Autowired
  private RepoBalanceService repoBalanceService;

  @Test
  public void updateBalance() throws Exception{
    String response = getResource("request.json");
    ObjectMapper mapper = new ObjectMapper();
    mapper.setDateFormat(new SimpleDateFormat("yyyy.MM.dd  HH:mm:ss z"));
    Order order= mapper.readValue(response,Order.class);
    if(order!=null){
      for(Product item:order.getProducts()){
        repoBalanceService.updateRepoBalance(item.getItemId(),item.getQuantity());
      }
    }
  }


  @Test
  public void getAvailableBalance() throws Exception{
    Assert.assertNotNull(repoBalanceService.getAvailableBalance(1));
  }

  */
/**
   *
   * @param filePatth
   * @return
   * @throws UnsupportedEncodingException
   * @throws IOException
   * @throws URISyntaxException
   *//*

  private String getResource(String filePatth) throws UnsupportedEncodingException, IOException, URISyntaxException {
    URI uri = this.getClass().getClassLoader().getResource(filePatth).toURI();
    String data = new String(Files.readAllBytes(Paths.get(uri)), Charset.forName("utf-8"));
    return data;
  }
}
*/
