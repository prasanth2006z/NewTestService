package com.nivi;

import com.nivi.pojo.Order;
import com.nivi.pojo.Purchase;
import com.nivi.service.OrderService;
import com.nivi.util.OrderUtil;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * @Author: pxp167
 * @Date: 9/28/2018
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
@ActiveProfiles(profiles = "dev")
@ContextConfiguration(classes = {Config.class})
@EnableAutoConfiguration
public class OrderServiceTest {
  @Autowired
  private OrderService orderService;

  @Test
  public void createOrderTest(){
    Purchase purchase=new Purchase();
    purchase.setProductId(6);
    purchase.setQuantity(20);

    List<Purchase> purchases=new ArrayList<>();
    purchases.add(purchase);


    Order order =new Order();
    order.setOrderStatus("success");
    order.setUserId(2);
    order.setProducts(purchases);
    order.setDeliveryStatus("Pending");
    order.setOrderDate(new Date());
    orderService.save(order);
  }

  @Test
  public void getOrders() {
    OrderUtil orderUtil=new OrderUtil();
    Map<String, Object>  map= orderUtil.getOrderDetails("");
  }

}
