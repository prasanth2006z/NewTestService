package com.nivi;

import com.nivi.pojo.Address;
import com.nivi.pojo.User;
import com.nivi.service.UserService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.Date;

/**
 * @Author: pxp167
 * @Date: 9/27/2018
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
@ActiveProfiles(profiles = "dev")
@ContextConfiguration(classes = {Config.class})
@EnableAutoConfiguration
public class UserServiceTest {

  @Autowired
  private UserService userService;

  @Test
  public  void createUserTest(){
    Address address=new Address();
    address.setFlatNo("2E");
    address.setBuildingName("Ultima Areosky");
    address.setCity("Cochin");
    address.setState("Kerala");
    address.setCountry("India");
    address.setPinCode("680551");
    address.setLocation("adasdasdsadasd");
    address.setLatitude("52.5651667");
    address.setLongitude("-8.7895846");

    User user=new User();
    user.setUserName("Prasanth");
    user.setAddress(address);
    user.setCreationDate(new Date());
    user.setPhoneNumber("9744020402");

    userService.createUser(user);
  }

  @Test
  public void testFindAll(){
    userService.getUsers();
  }




}
