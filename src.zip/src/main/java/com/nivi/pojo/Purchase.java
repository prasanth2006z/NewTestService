package com.nivi.pojo;

import javax.persistence.*;

/**
 * @Author: pxp167
 * @Date: 10/1/2018
 *
 */
@Entity
@Table(name="Purchase")
public class Purchase {
  private static final long serialVersionUID = 1L;
  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  @Column(name = "Purchase_Id")
  private long purchaseId;
  @Column(name = "Product_Id")
  private long productId;
  @Column(name = "Quantity")
  private int quantity;

  public long getPurchaseId() {
    return purchaseId;
  }

  public void setPurchaseId(long purchaseId) {
    this.purchaseId = purchaseId;
  }

  public long getProductId() {
    return productId;
  }

  public void setProductId(long productId) {
    this.productId = productId;
  }

  public int getQuantity() {
    return quantity;
  }

  public void setQuantity(int quantity) {
    this.quantity = quantity;
  }
}
