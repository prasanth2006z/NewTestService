package com.nivi.pojo;

import javax.persistence.*;
import java.util.Date;

/**
 * @Author: pxp167
 * @Date: 10/1/2018
 *
 */
@Entity
@Table(name="FEEDBACK")
public class FeedBack {
  private static final long serialVersionUID = 1L;
  @Id
  @GeneratedValue(strategy= GenerationType.AUTO)
  @Column(name="Feedback_ID")
  private long feedBackID;
  @Column(name="Order_ID")
  private long orderId;
  @Column(name="User_ID")
  private long userID;
  @Column(name="Created_Date")
  private Date created_date;

  public long getFeedBackID() {
    return feedBackID;
  }

  public void setFeedBackID(long feedBackID) {
    this.feedBackID = feedBackID;
  }

  public long getOrderId() {
    return orderId;
  }

  public void setOrderId(long orderId) {
    this.orderId = orderId;
  }

  public long getUserID() {
    return userID;
  }

  public void setUserID(long userID) {
    this.userID = userID;
  }

  public Date getCreated_date() {
    return created_date;
  }

  public void setCreated_date(Date created_date) {
    this.created_date = created_date;
  }
}
