package com.nivi.pojo;

import javax.persistence.*;
import java.util.Date;

/**
 * @Author: pxp167
 * @Date: 9/26/2018
 *
 */
@Entity
@Table(name="USER")
public class User {
  private static final long serialVersionUID = 1L;
  @Id
  @GeneratedValue(strategy= GenerationType.AUTO)
  @Column(name="USER_ID")
  private long userId;
  @Column(name="PHONE_NUMBER")
  private String phoneNumber;
  @Column(name="USER_NAME")
  private String userName;
  @OneToOne(cascade = CascadeType.ALL)
  private Address address;
  @Column(name="CREATED_DATE")
  private Date creationDate;

  public long getUserId() {
    return userId;
  }

  public void setUserId(long userId) {
    this.userId = userId;
  }

  public String getUserName() {
    return userName;
  }

  public void setUserName(String userName) {
    this.userName = userName;
  }

  public Address getAddress() {
    return address;
  }

  public void setAddress(Address address) {
    this.address = address;
  }

  public Date getCreationDate() {
    return creationDate;
  }

  public void setCreationDate(Date creationDate) {
    this.creationDate = creationDate;
  }

  public String getPhoneNumber() {
    return phoneNumber;
  }

  public void setPhoneNumber(String phoneNumber) {
    this.phoneNumber = phoneNumber;
  }
}
