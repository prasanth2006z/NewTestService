package com.nivi.pojo;

import javax.persistence.*;
import java.util.Date;

/**
 * @Author: pxp167
 * @Date: 9/26/2018
 *
 */
@Entity
@Table(name = "Product")
public class Product {
  private static final long serialVersionUID = 1L;
  @Id
  @GeneratedValue(strategy = GenerationType.AUTO)
  @Column(name = "product_Id")
  private long productId;
  @Column(name = "product_name")
  private String productName;
  @Column(name = "price")
  private long priceperUnit;
  @Column(name = "Created_Date")
  private Date createdDate;


  public long getProductId() {
    return productId;
  }

  public void setProductId(long productId) {
    this.productId = productId;
  }

  public String getProductName() {
    return productName;
  }

  public void setProductName(String productName) {
    this.productName = productName;
  }

  public long getPriceperUnit() {
    return priceperUnit;
  }

  public void setPriceperUnit(long priceperUnit) {
    this.priceperUnit = priceperUnit;
  }

  public Date getCreatedDate() {
    return createdDate;
  }

  public void setCreatedDate(Date createdDate) {
    this.createdDate = createdDate;
  }
}
