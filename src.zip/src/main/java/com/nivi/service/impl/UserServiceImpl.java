package com.nivi.service.impl;

import com.nivi.dao.UserDao;
import com.nivi.pojo.Address;
import com.nivi.pojo.User;
import com.nivi.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * @Author: pxp167
 * @Date: 9/28/2018
 *
 */
public class UserServiceImpl implements UserService {

  @Autowired
  private UserDao userDao;

  @Override public void createUser(User user) {
    userDao.save(user);
  }

  @Override public void updateUser(User user) {

  }

  @Override public void deleteUser(User user) {

  }

  @Override public Iterable<User> getUsers() {
    return userDao.findAll();
  }
}
