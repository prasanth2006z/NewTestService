package com.nivi.service.impl;

import com.nivi.dao.OrderDao;
import com.nivi.pojo.Order;
import com.nivi.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * @Author: pxp167
 * @Date: 9/26/2018
 *
 */
public class OrderServiceImpl implements OrderService {

  @Autowired
  private OrderDao orderDao;

  @Override public void save(Order order) {
    orderDao.save(order);
  }

  @Override public List<Order> getOrders() {
    return null;
  }

  @Override public void updateorders(List<Order> orders) {

  }

  @Override public void deleteOrderbyId(long orderId) {

  }

  @Override public List<Order> getPreviousOrderHistory(long userId) {
    return null;
  }

  @Override public Map<Long, String> getFeedBacks(Date fromDate, Date toDate) {
    return null;
  }

  @Override public List<Order> getOrders(String buildingName) {
    return null;
  }
}
