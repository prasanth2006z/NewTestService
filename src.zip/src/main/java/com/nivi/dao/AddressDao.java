package com.nivi.dao;

import com.nivi.pojo.Address;
import org.springframework.data.repository.CrudRepository;

/**
 * @Author: pxp167
 * @Date: 9/28/2018
 *
 */
public interface AddressDao extends CrudRepository<Address, Long> {

}
