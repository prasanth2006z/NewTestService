package com.nivi.dao;

import com.nivi.pojo.User;
import org.springframework.data.repository.CrudRepository;

/**
 * @Author: pxp167
 * @Date: 9/28/2018
 *
 */
public interface UserDao extends CrudRepository<User, Long> {
}
