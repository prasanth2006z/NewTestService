package com.nivi.dao;

import com.nivi.pojo.Product;
import org.springframework.data.repository.CrudRepository;

/**
 * @Author: pxp167
 * @Date: 9/28/2018
 *
 */
public interface ProductDao extends CrudRepository<Product, Long> {
}
