package com.nivi;

import com.nivi.service.OrderService;
import com.nivi.service.ProductService;
import com.nivi.service.RepoBalanceService;
import com.nivi.service.UserService;
import com.nivi.service.impl.OrderServiceImpl;
import com.nivi.service.impl.ProductServiceImpl;
import com.nivi.service.impl.RepoBalanceServiceImpl;
import com.nivi.service.impl.UserServiceImpl;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

/**
 * @Author: pxp167
 * @Date: 9/26/2018
 *
 */
@ComponentScan(basePackages = "com.nivi")
@Configuration
public class Config {

  /**
   *
   * @return
   */
  @Bean
  public RepoBalanceService repoBalanceService() {
    return new RepoBalanceServiceImpl();
  }

  /**
   *
   * @return
   */
  @Bean
  public OrderService orderService() {
    return new OrderServiceImpl();
  }



  /**
   *
   * @return
   */
  @Bean
  public UserService userService() {
    return new UserServiceImpl();
  }

  /**
   *
   * @return
   */
  @Bean
  public ProductService productService(){
    return new ProductServiceImpl();
  }

}
