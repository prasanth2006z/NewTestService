package com.nivi.util;

import org.apache.commons.lang3.StringUtils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

/**
 * @Author: pxp167
 * @Date: 10/1/2018
 *
 */
public class OrderUtil {

  Map<String, Object> orderMap = new HashMap<>();
  private Connection connection = null;
  private ResultSet resultSet = null;
  private PreparedStatement preparedStatement = null;
  private Properties properties = null;

  String ORDER_LIST = "SELECT U.PHONE_NUMBER,PR.PRODUCT_NAME,P.QUANTITY,A.FLAT_NO,A.BUILDING_NAME,o.order_date FROM ORDERS O INNER JOIN ORDERS_PRODUCTS OP ON O.\n"
    + "ORDER_ID=OP.ORDER_ORDER_ID INNER JOIN PURCHASE P ON P.purchase_id=OP.products_purchase_id INNER JOIN         USER U ON O.USER_ID=U.USER_ID INNER\n"
    + "JOIN ADDRESS A ON U.ADDRESS_ADDRESS_ID=A.ADDRESS_ID inner join product pr on p.product_id=pr.product_id WHERE HOUR(o.order_date) <= ?";

  /**
   *
   * @return
   */
  public Map<String, Object> getOrderDetails(String shift) {
    try {
      connection = DBConnector.initialiseDatabaseConnection();
      if (connection != null) {
        preparedStatement = connection.prepareStatement(ORDER_LIST);
        if(StringUtils.isNotEmpty(shift)){
          preparedStatement.setString(1, shift);
        }else{
          preparedStatement.setString(1, "12");
        }
        resultSet = preparedStatement.executeQuery();
        while (resultSet != null && resultSet.next()) {
          String phoneNumber = resultSet.getString("PHONE_NUMBER");
          String FLAT_NO = resultSet.getString("FLAT_NO");
          String BUILDING_NAME = resultSet.getString("BUILDING_NAME");
          String PRODUCT_NAME = resultSet.getString("PRODUCT_NAME");
          String QUANTITY = resultSet.getString("QUANTITY");
          if(orderMap.containsKey(phoneNumber)){
            Map<String, Object> map = getOrder(phoneNumber, FLAT_NO, BUILDING_NAME, PRODUCT_NAME, QUANTITY);
            orderMap.put(phoneNumber,map);

          }else{
            Map<String, Object> map = getOrderMap(FLAT_NO, BUILDING_NAME);
            getProductMap(PRODUCT_NAME, QUANTITY, map);
            orderMap.put(phoneNumber,map);
          }
        }
      }
      DBConnector.closingPreparedStatement(preparedStatement, resultSet);
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      DBConnector.closeConnection();
    }
    return orderMap;
  }



  private Map<String, Object> getOrder(String phoneNumber, String FLAT_NO, String BUILDING_NAME, String PRODUCT_NAME, String QUANTITY) {
    Map<String,Object> map= (Map<String, Object>) orderMap.get(phoneNumber);
    map.put("FLAT_NO",FLAT_NO);
    map.put("BUILDING_NAME",BUILDING_NAME);
    if(map.containsKey("products")){
      Map<String,Object> productMap= (Map<String, Object>) map.get("products");
      productMap.put(PRODUCT_NAME,QUANTITY);
      map.put("products",productMap);
    }else{
      getProductMap(PRODUCT_NAME, QUANTITY, map);
    }
    return map;
  }

  private Map<String, Object> getOrderMap(String FLAT_NO, String BUILDING_NAME) {
    Map<String,Object> map=new HashMap<>();
    map.put("FLAT_NO",FLAT_NO);
    map.put("BUILDING_NAME",BUILDING_NAME);
    return map;
  }

  private void getProductMap(String PRODUCT_NAME, String QUANTITY, Map<String, Object> map) {
    Map<String,Object> productMap=new HashMap<>();
    productMap.put(PRODUCT_NAME,QUANTITY);
    map.put("products",productMap);
  }

}
